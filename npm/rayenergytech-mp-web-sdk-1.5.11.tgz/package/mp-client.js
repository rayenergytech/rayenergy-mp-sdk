/* Business client companion to mp-tracker.js; APP/API/client/installation-scoped token persistence; no cached user privileges. */
(function (global) {
  'use strict'
  var SDK_VERSION = '1.5.11'
  function MpClient(options) {
    if (options && options.tracker) {
      var tracked = options.tracker.appVersionCode
      var code = options.versionCode == null ? (tracked == null ? undefined : Number(tracked)) : options.versionCode
      if (tracked != null && (!/^[0-9]{1,10}$/.test(String(tracked)) || Number(tracked) !== code)) throw new Error('versionCode differs from tracker build code')
      options = Object.assign({}, options, {versionCode: code})
    }
    if (!options || !options.tracker || !options.appCode || !options.apiBase || (!Number.isInteger(options.versionCode) || options.versionCode < 0 || options.versionCode > 2147483647)) throw new Error('tracker, appCode, apiBase and integer versionCode are required')
    if (![1, 2, 3].includes(options.platform)) throw new Error('platform must be 1, 2 or 3')
    if (Object.prototype.hasOwnProperty.call(options, 'directBaseUrl')) throw new Error('Configure directBaseUrl on MpTracker; MpClient inherits the same origin')
    if (options.tracker.directBaseUrl && options.platform !== 3) throw new Error('Browser direct mode requires platform=3')
    if (options.guestRestoreMode != null && options.guestRestoreMode !== 'same_user_restricted') throw new Error('Invalid guestRestoreMode')
    if(options.autoGuestLogin!=null && typeof options.autoGuestLogin!=='boolean')throw new Error('autoGuestLogin must be boolean')
    this.autoGuestLogin=options.autoGuestLogin!==false
    this.webRecovery=options.webRecovery===true
    this.initializationError=null
    Object.defineProperty(this, 'guestRestoreMode', {value: options.guestRestoreMode || null, enumerable: true})
    this.paymentEnvironment = options.paymentEnvironment || 'production'
    if (!['sandbox', 'production'].includes(this.paymentEnvironment)) throw new Error('Invalid paymentEnvironment')
    this.tracker = options.tracker
    this.tracker.appVersionCode = options.versionCode
    this.apiBase = options.apiBase.replace(/\/$/, '')
    // apiBase still identifies the existing Token cache. Never fall back to it on transport failure.
    Object.defineProperty(this, 'directBaseUrl', {value: this.tracker.directBaseUrl || null, enumerable: true})
    this._baseContext = {appCode: options.appCode, platform: options.platform, versionCode: options.versionCode, deviceId: options.tracker.deviceId}
    var fields = {}
    ;['country', 'language', 'channel', 'adGroup', 'adCreative'].forEach(function (key) {
      if (Object.prototype.hasOwnProperty.call(options, key)) fields[key] = options[key]
    })
    if (typeof this.tracker.setRuleContext === 'function') this.tracker.setRuleContext(fields)
    else Object.assign(this._baseContext, fields) // Compatibility for custom tracker adapters.
    if (options.paymentChannel != null) this._baseContext.paymentChannel = options.paymentChannel
    this.onSessionChanged = null; this._renewPromise = null; this.closed = false; this.token = null; this.epoch = 0; this.sequence = 0; this.timeoutMs = options.timeoutMs || 15000
    this.sessionKey = '__mp_client_session_v1__:' + encodeURIComponent(JSON.stringify([this.apiBase, options.appCode, options.platform, this.context.deviceId]))
    this.sessionStorageError = null
    try { this.storage = options.sessionStorage || global.localStorage; this.token = this.storage ? this.storage.getItem(this.sessionKey) : null; if (!this.storage) this.sessionStorageError = 'Token cache unavailable' }
    catch (e) { this.token = null; this.sessionStorageError = 'Token cache unavailable' }
    this._clearIdentity()
    var self = this
    if (typeof this.tracker.setCollectionTokenProvider === 'function') {
      // Only send a business credential to the same configured gateway (or inherited direct origin).
      this.tracker.setCollectionTokenProvider(this.directBaseUrl || this.tracker.endpoint === this.apiBase
        ? function () { return self.closed ? null : self.token } : null)
    }
    this._storageListener = function (event) { if ((event.key === self.sessionKey || event.key === null) && event.storageArea === self.storage) { self.epoch++; self.sequence++; self.token = event.newValue || null; self._clearIdentity(); if (self.onSessionChanged) { try { self.onSessionChanged() } catch (_) {} } } }
    if (global.addEventListener) global.addEventListener('storage', this._storageListener)
    this._autoGuestEligible=!this.token && !this.sessionStorageError
    var startupEpoch=this.epoch,startupSequence=this.sequence
    this.ready=Promise.resolve().then(function(){
      if(!self.autoGuestLogin || self._autoStartupCancelled || self.closed)return null
      if(self._guestLoginPromise)return self._guestLoginPromise
      if(startupEpoch!==self.epoch || startupSequence!==self.sequence)return null // The host explicitly took over the session.
      return self.initializeSession()
    })
    this.ready.catch(function(error){self.initializationError=error;if(typeof options.onInitializationError==='function'){try{options.onInitializationError(error)}catch(_){}}})
  }
  Object.defineProperty(MpClient.prototype, 'context', {get: function () {
    return Object.assign({}, this._baseContext, typeof this.tracker.getRuleContext === 'function' ? this.tracker.getRuleContext() : {})
  }})
  Object.defineProperty(MpClient.prototype, 'hasSession', {get: function () { return !!this.token }})
  MpClient.prototype._clearIdentity = function () {
    this.tracker._runtimeFields = {user_id: '', ab_snapshot: '{}', config_version: ''}
  }
  MpClient.prototype.setSession = function (accessToken) {
    if (this.closed) throw new Error('Client closed')
    if (accessToken != null && typeof accessToken !== 'string') throw new Error('Invalid access token')
    this.epoch++; this.sequence++; this.token = accessToken && accessToken.trim() ? accessToken : null
    this._clearIdentity()
    try {
      if (!this.storage) throw new Error('Storage unavailable')
      if (this.token) this.storage.setItem(this.sessionKey, this.token)
      else this.storage.removeItem(this.sessionKey)
      this.sessionStorageError = null
    } catch (e) {
      this.sessionStorageError = 'Token cache unavailable'
      try { if (this.storage) this.storage.removeItem(this.sessionKey) } catch (_) {}
    }
    if (this.onSessionChanged) { try { this.onSessionChanged() } catch (_) {} }
  }
  MpClient.prototype.clearLocalSession = function () { if (this.tracker._resolveStartupIdentity) this.tracker._resolveStartupIdentity(null); this.setSession(null) }
  MpClient.prototype.initializeSession = function () {
    if(this._initializationPromise)return this._initializationPromise
    var self=this
    this._initializationPromise=Promise.resolve().then(function(){
      if(self.closed)throw new Error('Client closed')
      if(self._guestLoginPromise)return self._guestLoginPromise
      if(!self.token && self.sessionStorageError)throw new Error('Token cache unavailable; retry storage or explicitly login')
      if(self.token)return self.refresh()
      if(self._autoStartupCancelled)throw new Error('Session initialization superseded by explicit login')
      if(!self._autoGuestEligible)throw new Error('Login required')
      return self.loginGuest()
    }).finally(function(){self._initializationPromise=null})
    return this._initializationPromise
  }
  MpClient.prototype._recoverDeletedSession = function () {
    if (this._deletedRecovery) return this._deletedRecovery
    var self=this, source=this.token
    this._deletedRecoveryToken=source
    this._deletedRecovery=Promise.resolve().then(async function () {
      if (!source || self.closed || self.token!==source) throw new Error('Session changed; discarded recovery')
      // Keep the already revoked credential only as recovery proof, including on a network failure.
      var epoch=self.epoch+1
      self.setSession(source)
      if(epoch!==self.epoch || self.token!==source)throw new Error('Session changed; discarded recovery')
      var device=self._accountBody()
      if(self.context.platform===3 && typeof self.tracker.webIdentityContext==='function') device.webContext=self.tracker.webIdentityContext()
      var login=await self._post('/api/v1/client/accounts/recover-deleted',{device:device,deletedToken:source},epoch,false)
      if(epoch!==self.epoch)throw new Error('Session changed; discarded recovery')
      self._validateGuestRestoreMode(login)
      if(typeof login.accessToken!=='string'||!login.accessToken.trim())throw new Error('Missing access token')
      epoch=self.epoch+1;self.setSession(login.accessToken)
      if(epoch!==self.epoch || self.token!==login.accessToken)throw new Error('Session changed; discarded recovery')
      var configuration=await self.refresh()
      return {configuration:configuration,epoch:self.epoch,sequence:self.sequence}
    }).finally(function () { self._deletedRecovery=null; self._deletedRecoveryToken=null })
    return this._deletedRecovery
  }
  MpClient.prototype._post = async function (path, body, epoch, authenticated) {
    if (this.closed) throw new Error('Client closed')
    var controller = new AbortController(), timer = setTimeout(function () { controller.abort() }, this.timeoutMs)
    try {
      var headers = {'Content-Type': 'application/json', 'X-Payment-Environment': this.paymentEnvironment}
      if (authenticated) { if (!this.token) throw new Error('Login required'); headers.Authorization = 'Bearer ' + this.token }
      var request = {method: 'POST', headers: headers, body: JSON.stringify(body), signal: controller.signal}
      if (this.directBaseUrl) { request.credentials = 'omit'; request.redirect = 'error' }
      var response = await global.fetch((this.directBaseUrl || this.apiBase) + path, request)
      var result
      try { result = await response.json() }
      catch (parseError) { if (authenticated && epoch === this.epoch && response.status === 401) {this._autoGuestEligible=false;this.clearLocalSession()}; throw parseError }
      if (epoch !== this.epoch) throw new Error('Session changed; discarded response')
      if(authenticated && result.code===40108){
        if(this._deletedRecovery && this._deletedRecoveryToken!==this.token)throw new Error('Replacement session unavailable')
        var recovered=await this._recoverDeletedSession()
        if(this.closed || recovered.epoch!==this.epoch)throw new Error('Session changed; discarded recovery')
        var replaced=new Error('Account deleted; a new guest session is ready. Retry the operation explicitly.')
        replaced.code=40108;replaced.sessionRecovered=true;replaced.configuration=recovered.configuration;replaced.recoveryEpoch=recovered.epoch;replaced.recoverySequence=recovered.sequence
        throw replaced
      }
      if (authenticated && (response.status === 401 || result.code === 40101 || result.code === 40302)) {this._autoGuestEligible=false;this.clearLocalSession()}
      if (!response.ok || result.code !== 0) { var error = new Error(result.message || 'Request failed'); error.code = result.code; throw error }
      return result.data
    } finally { clearTimeout(timer) }
  }
  MpClient.prototype.loginGuest = function () {
    if(this._guestLoginPromise)return this._guestLoginPromise
    var accept,reject,self=this
    var flight=new Promise(function(resolve,fail){accept=resolve;reject=fail})
    this._guestLoginPromise=flight
    this._loginGuestImpl().then(function(value){self._guestLoginPromise=null;accept(value)},function(error){self._guestLoginPromise=null;reject(error)})
    return flight
  }
  MpClient.prototype._loginGuestImpl = async function () {
    if (!this.guestRestoreMode) this.setSession(null)
    var epoch = this.epoch, body = {appCode: this.context.appCode, deviceId: this.context.deviceId, platform: {1: 'ios', 2: 'android', 3: 'web'}[this.context.platform], country: this.context.country,channel:this.context.channel || 'organic'}
    if (this.context.platform === 3 && typeof this.tracker.webIdentityContext === 'function') body.webContext = this.tracker.webIdentityContext()
    if (this.context.platform === 3 && this.webRecovery) body.webContext = Object.assign({}, body.webContext, {recoveryConfirmation:true})
    if (this.guestRestoreMode) body.guestRestoreMode = this.guestRestoreMode
    var result = await this._post('/api/v1/client/users/login/guest', body, epoch, false)
    if (epoch !== this.epoch) throw new Error('Session changed; discarded response')
    this._validateGuestRestoreMode(result)
    if (typeof result.accessToken !== 'string' || !result.accessToken.trim()) throw new Error('Missing access token')
    this._autoGuestEligible=false
    this.setSession(result.accessToken)
    return this.refresh()
  }
  MpClient.prototype._accountBody = function (fields) {
    var body = Object.assign({}, this.context.country == null ? {} : {country:this.context.country}, fields || {}, {appCode: this.context.appCode, deviceId: this.context.deviceId, platform: {1:'ios',2:'android',3:'web'}[this.context.platform]})
    delete body.guestRestoreMode
    body.channel=this.context.channel || 'organic'
    if (this.guestRestoreMode) body.guestRestoreMode = this.guestRestoreMode
    return body
  }
  MpClient.prototype._validateGuestRestoreMode = function (login) {
    if (this.guestRestoreMode && (!login || login.guestRestoreMode !== this.guestRestoreMode)) {
      var error = new Error('Unsupported guest restore mode: server did not confirm ' + this.guestRestoreMode)
      error.code = 'guest_restore_mode_unsupported'
      throw error
    }
  }
  MpClient.prototype._changeAccount = async function (path, fields, authenticated) {
    if(authenticated===false){this._autoStartupCancelled=true;if(this._guestLoginPromise)this.setSession(this.token)}
    var epoch = this.epoch
    var login = await this._post('/api/v1/client/accounts/' + path, this._accountBody(fields), epoch, authenticated)
    if (epoch !== this.epoch) throw new Error('Session changed; discarded response')
    this._validateGuestRestoreMode(login)
    if (typeof login.accessToken !== 'string' || !login.accessToken) throw new Error('Missing access token')
    this.setSession(login.accessToken)
    return this.refresh()
  }
  // Handoff state is scoped exactly like the session. Never send the verifier to an MMP.
  MpClient.prototype._handoff = function (action, fields, authenticated) {
    return this._post('/api/v1/client/handoff/' + action, this._accountBody(fields || {}), this.epoch, !!authenticated)
  }
  MpClient.prototype.handoffConfig = function () { return this._handoff('config') }
  MpClient.prototype.getAppHandoffSource = function () { return this._handoff('current',{},true) }
  MpClient.prototype.createAppHandoff = function (routeKey, source) { return this._handoff('create', {routeKey:routeKey || 'home',source:source || {}},true) }
  MpClient.prototype.createWebRecovery = function () {
    if(this.context.platform!==3)return Promise.reject(new Error('Web client required'))
    return this._handoff('web-recovery/create',{},true)
  }
  MpClient.prototype.pendingAppHandoffs = function () { return this._handoff('pending',{},true).then(function(result){return result.claims}) }
  MpClient.prototype.confirmAppHandoff = function (claimId, pairCode, approve) { return this._handoff('approve',{claimId:claimId,pairCode:pairCode,approve:approve===true},true) }
  MpClient.prototype.watchAppHandoffs = function (onPending, onError) {
    var self=this, stopped=false, timer
    async function poll() { try { var pending=await self.pendingAppHandoffs();if(!stopped)onPending(pending) } catch(e) {if(!stopped&&onError)onError(e)} if(!stopped)timer=setTimeout(poll,5000) }
    poll();return function(){stopped=true;clearTimeout(timer)}
  }
  // Optional H5 confirmation widget. No authorization is performed until a user clicks Confirm.
  MpClient.prototype.mountAppHandoffPrompt = function (container) {
    if(this.context.platform!==3||!container||!global.document)throw new Error('H5 DOM container required')
    var self=this,document=global.document,root=document.createElement('section');container.appendChild(root)
    function message(text){root.textContent=text}
    var stop=this.watchAppHandoffs(function(claims){
      root.textContent=''
      claims.forEach(function(claim){
        var box=document.createElement('div'),label=document.createElement('p'),yes=document.createElement('button'),no=document.createElement('button')
        var target=claim.platform==='web'?'另一个浏览器':'APP'
        label.textContent=target+'请求继续使用本页游客账号。请核对配对码：'+claim.pairCode+'（'+claim.platform+'）。仅确认你刚刚发起的请求。'
        yes.textContent='配对一致，确认接续';no.textContent='拒绝'
        function decide(approve){yes.disabled=true;no.disabled=true;self.confirmAppHandoff(claim.claimId,claim.pairCode,approve).then(function(){message(approve?'已确认，请回到'+target+'继续。':'已拒绝本次接续。')}).catch(function(){message('请求未完成，请检查网络后重新确认。')})}
        yes.onclick=function(){decide(true)};no.onclick=function(){decide(false)}
        box.appendChild(label);box.appendChild(yes);box.appendChild(no);root.appendChild(box)
      })
    },function(){message('接续状态暂时无法获取，请检查网络或恢复本页游客会话。')})
    return function(){stop();root.remove()}
  }
  MpClient.prototype._handoffHash = async function (text) {
    if(!global.crypto || !global.crypto.subtle)throw new Error('Secure crypto unavailable')
    var bytes=new Uint8Array(await global.crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))
    return Array.from(bytes,function(b){return b.toString(16).padStart(2,'0')}).join('')
  }
  MpClient.prototype._pendingHandoff = function (value) {
    if(!this.storage)throw new Error('Secure pending storage unavailable')
    var key=this.sessionKey+':handoff'
    if(arguments.length){if(value)this.storage.setItem(key,JSON.stringify(value));else this.storage.removeItem(key);return value}
    var text=this.storage.getItem(key);return text?JSON.parse(text):null
  }
  MpClient.prototype.resolveAppHandoff = async function (input, provider) {
    var config=await this.handoffConfig(), id
    if(config.protocolVersion!==1||!config.enabled)throw new Error('Handoff unavailable')
    if(provider){
      if(provider!==config.provider)throw new Error('Unsupported provider configuration')
      if(provider==='appsflyer')id=input[config.parameter]
      else if(provider==='adjust')id=new URL(input).searchParams.get(config.parameter)
      else throw new Error('Unsupported provider')
    } else {
      var url=new URL(input), base=new URL(config.baseUrl)
      var nativeScheme=config.scheme&&url.protocol===config.scheme+':'&&url.hostname==='handoff'
      if(!nativeScheme&&(url.origin!==base.origin||url.pathname!=='/api/v1/public/handoff/'+encodeURIComponent(this.context.appCode)))throw new Error('Untrusted handoff URL')
      if(nativeScheme&&url.searchParams.get('appCode')!==this.context.appCode)throw new Error('APP mismatch')
      id=url.searchParams.get('handoffId')
    }
    if(typeof id!=='string'||!/^[A-Za-z0-9_-]{20,64}$/.test(id))throw new Error('Missing handoff context')
    var result=await this._handoff('resolve',{handoffId:id});return Object.assign({handoffId:id},result)
  }
  MpClient.prototype.beginAppHandoff = async function (handoffId) {
    if(this.context.platform===3)throw new Error('Native client required')
    return this._beginHandoff(handoffId)
  }
  MpClient.prototype.beginWebRecovery = async function (handoffId) {
    if(this.context.platform!==3)throw new Error('Web client required')
    if(typeof handoffId!=='string'||!/^[A-Za-z0-9_-]{20,64}$/.test(handoffId))throw new Error('Invalid recovery identifier')
    this._autoStartupCancelled=true
    if(this._guestLoginPromise)await this._guestLoginPromise.catch(function(){})
    return this._beginHandoff(handoffId)
  }
  MpClient.prototype._beginHandoff = async function (handoffId) {
    var pending=this._pendingHandoff(), generation=this.epoch
    if(!pending){
      if(!global.crypto||!global.crypto.getRandomValues)throw new Error('Secure crypto unavailable')
      var bytes=global.crypto.getRandomValues(new Uint8Array(32))
      var verifier=Array.from(bytes,function(b){return b.toString(16).padStart(2,'0')}).join('')
      var uuid=global.crypto.randomUUID()
      pending={claimId:uuid,handoffId:handoffId,verifier:verifier,oldTokenHash:await this._handoffHash(this.token||''),phase:'pending'}
      if(generation!==this.epoch)throw new Error('Session changed')
      this._pendingHandoff(pending)
    }
    if(pending.handoffId!==handoffId)throw new Error('Cancel existing handoff first')
    var challenge=await this._handoffHash(pending.verifier)
    if(generation!==this.epoch || await this._handoffHash(this.token||'')!==pending.oldTokenHash || generation!==this.epoch)throw new Error('Session changed')
    var result=await this._handoff('claim',{claimId:pending.claimId,handoffId:handoffId,challenge:challenge},this.hasSession)
    return result
  }
  MpClient.prototype.appHandoffStatus = function () { var p=this._pendingHandoff();if(!p)throw new Error('No pending handoff');return this._handoff('status',{claimId:p.claimId,verifier:p.verifier}) }
  MpClient.prototype.completeAppHandoff = async function (switchConfirmed) {
    if(switchConfirmed!==true)throw new Error('Explicit switch confirmation required')
    var p=this._pendingHandoff();if(!p)throw new Error('No pending handoff')
    var current=await this._handoffHash(this.token||''),generation=this.epoch
    if(current!==p.oldTokenHash&&current!==p.newTokenHash)throw new Error('Session changed; start a new handoff')
    var body={claimId:p.claimId,verifier:p.verifier,switchConfirmed:true}
    // A lost ACK response is recoverable using the already persisted session.
    var state=await this._handoff('status',body)
    if(['acknowledged','delivered','recovery_expired'].includes(state.status)&&current===p.newTokenHash){var verified=await this.getAccount();if(verified.userId!==p.newUserId)throw new Error('Handoff account mismatch');this.tracker._runtimeFields.user_id=verified.userId;if(state.status!=='acknowledged')await this._handoff('ack',body,true);this._pendingHandoff(null);return Object.assign({claimId:p.claimId,status:'acknowledged'},verified)}
    var login=await this._handoff('redeem',body)
    if(typeof login.accessToken!=='string'||!login.accessToken||typeof login.userId!=='string')throw new Error('Invalid handoff session')
    p.newTokenHash=await this._handoffHash(login.accessToken);p.newUserId=login.userId
    if(generation!==this.epoch)throw new Error('Session changed; discarded handoff')
    this._pendingHandoff(p)
    // Persist before touching memory; storage failure must preserve the old session.
    this.storage.setItem(this.sessionKey,login.accessToken)
    this.token=login.accessToken;this.epoch++;this.sequence++;this.sessionStorageError=null;this._clearIdentity()
    if(this.onSessionChanged){try{this.onSessionChanged()}catch(_){}}
    var account=await this.getAccount();if(account.userId!==login.userId)throw new Error('Handoff account mismatch')
    this.tracker._runtimeFields.user_id=login.userId
    await this._handoff('ack',body,true);this._pendingHandoff(null)
    return login
  }
  MpClient.prototype.cancelAppHandoff = async function () {var p=this._pendingHandoff();if(!p)return;await this._handoff('cancel',{claimId:p.claimId,verifier:p.verifier});this._pendingHandoff(null)}
  MpClient.prototype.reportAppHandoff = function (eventType,handoffId,eventId) {return this._handoff('event',{eventType:eventType,handoffId:handoffId||'',eventId:eventId||global.crypto.randomUUID()})}
  MpClient.prototype.getAccount = function () { return this._post('/api/v1/client/accounts/current', {}, this.epoch, true) }
  MpClient.prototype.requestVerification = function (provider, identifier, purpose) { return this._post('/api/v1/client/accounts/verification', this._accountBody({provider:provider,identifier:identifier,purpose:purpose}), this.epoch, purpose !== 'login' && purpose !== 'reset') }
  MpClient.prototype.loginMethods = function () { return this._post('/api/v1/client/accounts/login-methods',this._accountBody({}),this.epoch,false) }
  MpClient.prototype.oauthChallenge = function (provider) { return this._post('/api/v1/client/accounts/oauth/challenge', this._accountBody({provider:provider}), this.epoch, false) }
  MpClient.prototype.loginIdentity = function (proof) { return this._changeAccount('login', proof, false) }
  MpClient.prototype.loginPassword = function (email,password) { return this._changeAccount('password/login', {identifier:email,password:password}, false) }
  // One identity mutation; preserve its result even if the following configuration read is unavailable.
  MpClient.prototype.loginOrBindIdentity = async function (proof) {
    var generation = this.epoch
    var login = await this._post('/api/v1/client/accounts/login-or-bind', this._accountBody(proof), generation, true)
    if (generation !== this.epoch) throw new Error('Session changed; discarded response')
    this._validateGuestRestoreMode(login)
    if (!login || typeof login.accessToken !== 'string' || !login.accessToken.trim() || typeof login.userId !== 'string' || !login.userId || !['guest_upgraded','existing_account_login'].concat(this.guestRestoreMode ? ['account_reauthenticated'] : []).includes(login.action) || login.accountSwitched !== (login.action === 'existing_account_login')) throw new Error('Invalid identity resolution')
    generation = this.epoch + 1
    this.setSession(login.accessToken)
    if (generation !== this.epoch || this.token !== login.accessToken) throw new Error('Session changed; discarded response')
    this.tracker._runtimeFields = {user_id: login.userId, ab_snapshot: '{}', config_version: ''}
    var configuration = null
    try { configuration = await this.refresh() }
    catch (error) { if (this.closed || generation !== this.epoch || !this.token) throw error }
    if (this.closed || generation !== this.epoch) throw new Error('Session changed; discarded response')
    return Object.assign({}, login, {configuration: configuration, configurationRefreshRequired: configuration === null})
  }
  MpClient.prototype.bindIdentity = function (proof) { return this._changeAccount('bind', proof, true) }
  MpClient.prototype.replaceIdentity = function (previous,replacement) { return this._changeAccount('replace',{previous:this._accountBody(previous),replacement:this._accountBody(replacement)},true) }
  MpClient.prototype.unbindIdentity = function (proof) { return this._changeAccount('unbind',proof,true) }
  MpClient.prototype.renewSession = function () {
    if (this._renewPromise) return this._renewPromise
    var self = this
    this._renewPromise = this._changeAccount('session/refresh', {}, true).catch(function(error){if(error.sessionRecovered&&error.recoveryEpoch===self.epoch&&!self.closed)return error.configuration;throw error}).finally(function () { self._renewPromise = null })
    return this._renewPromise
  }
  // Obtain a fresh audience-bound ticket after token rotation. Each caller receives its own one-use ticket.
  MpClient.prototype.renewSessionForBusiness = async function (connectionId) {
    await this.renewSession()
    return this.businessTicket(connectionId)
  }
  // The host owns HTTPS business transport and token storage; never forward the middle-platform token.
  MpClient.prototype.loginBusiness = async function (connectionId, exchangeTicket) {
    if (typeof exchangeTicket !== 'function') throw new Error('exchangeTicket callback required')
    var generation = this.epoch, ticket = await this.businessTicket(connectionId)
    if (this.closed || generation !== this.epoch) throw new Error('Session changed; discarded business ticket')
    if (!ticket || typeof ticket.ticket !== 'string' || !ticket.ticket.trim()) throw new Error('Missing ticket')
    var result = await exchangeTicket(ticket.ticket)
    if (this.closed || generation !== this.epoch) throw new Error('Session changed; discarded business response')
    return result
  }
  MpClient.prototype.logout = function (allDevices) { return this._changeAccount('logout' + (allDevices ? '?allDevices=true' : ''), {}, true) }
  MpClient.prototype.getSessions = function () { return this._post('/api/v1/client/accounts/sessions',{},this.epoch,true) }
  MpClient.prototype.revokeSession = function (id) { return this._post('/api/v1/client/accounts/sessions/revoke',{sessionId:id},this.epoch,true) }
  MpClient.prototype.businessTicket = function (connectionId) { return this._post('/api/v1/client/accounts/business-ticket',{connectionId:connectionId},this.epoch,true) }
  MpClient.prototype.resetPassword = function (proof) { return this._post('/api/v1/client/accounts/password/reset',this._accountBody(proof),this.epoch,false) }
  MpClient.prototype.deletionPrecheck = function () { return this._post('/api/v1/client/accounts/deletion/precheck',{},this.epoch,true) }
  MpClient.prototype.deleteAccount = async function (proof) {
    var epoch = this.epoch
    var result = await this._post('/api/v1/client/accounts/deletion',this._accountBody(proof),epoch,true)
    if (epoch !== this.epoch) throw new Error('Session changed; discarded response')
    this.clearLocalSession()
    return result // Keep the receipt; call loginGuest explicitly to restore the original guest, or create one if none remains.
  }
  MpClient.prototype.deletionStatus = function (receipt) { return this._post('/api/v1/client/accounts/deletion/status',receipt,this.epoch,false) }
  MpClient.prototype.getUserInfo = async function () {if(this.autoGuestLogin&&!this._autoStartupCancelled&&!this.token&&(this._guestLoginPromise||this._autoGuestEligible))return (await this.loginGuest()).user;try{return await this._post('/api/v1/client/runtime/user', this.context, this.epoch, true)}catch(error){if(error.sessionRecovered&&error.recoveryEpoch===this.epoch&&!this.closed)return error.configuration.user;throw error} }
  MpClient.prototype.refresh = async function () {
    if(this.autoGuestLogin&&!this._autoStartupCancelled&&!this.token&&(this._guestLoginPromise||this._autoGuestEligible))return this.loginGuest()
    var epoch = this.epoch, sequence = ++this.sequence
    var result
    try{result=await this._post('/api/v1/client/runtime/config', this.context, epoch, true)}catch(error){if(error.sessionRecovered&&error.recoveryEpoch===this.epoch&&error.recoverySequence===this.sequence&&!this.closed)return error.configuration;throw error}
    if (sequence !== this.sequence) throw new Error('Superseded configuration response')
    this.tracker._runtimeFields = {user_id: result.user.userId, ab_snapshot: JSON.stringify(result.experiments || {}), config_version: result.configVersion}
    return result
  }
  MpClient.prototype.close = function () {
    if (this.closed) return
    if (this.onSessionChanged) { try { this.onSessionChanged() } catch (_) {} }
    if (this.tracker._resolveStartupIdentity) this.tracker._resolveStartupIdentity(null)
    this.closed = true; this.epoch++; this.sequence++; this.token = null; this._clearIdentity()
    if (global.removeEventListener) global.removeEventListener('storage', this._storageListener)
  }
  Object.defineProperty(MpClient, 'sdkVersion', {value: SDK_VERSION})
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = MpClient
    if (typeof window === 'undefined') return
  }
  global.MpClient = MpClient
})(typeof window !== 'undefined' ? window : globalThis)
