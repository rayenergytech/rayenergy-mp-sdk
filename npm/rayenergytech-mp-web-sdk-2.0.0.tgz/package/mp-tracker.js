/**
 * MP Tracking Web SDK
 * 协议：POST {directBaseUrl || endpoint}/api/v1/track/collect
 * 能力：自动采集公共字段、批量/定时上报、离线缓存(localStorage)、失败重传(指数退避)
 */
(function (global) {
  'use strict'

  var SDK_VERSION = '2.0.0'
  var STORAGE_KEY = '__mp_track_queue__'
  var DEVICE_KEY = '__mp_device_id__'
  var instances = Object.create(null)
  var RULE_EVENT_KEYS = {country: 'country_code', language: 'device_language', channel: 'channel', adGroup: 'adgroup', adCreative: 'creative'}
  function contextValue(value) {
    if (value == null) return undefined
    if (typeof value !== 'string') throw new Error('Rule context values must be strings or null')
    return value.trim() ? value : undefined
  }
  function acquisitionChannel(raw) {
    if(raw==null)return 'organic'
    if(typeof raw!=='string')throw new Error('channel must be a string')
    var value=raw.trim()
    if(!value || /^(organic|web|ogannic|unknown|undefined|null|未知|未上报|自然量)$/i.test(value))return 'organic'
    if(value.length>64)throw new Error('channel must be at most 64 characters')
    return value
  }

  function directOrigin(config) {
    if (!Object.prototype.hasOwnProperty.call(config, 'directBaseUrl')) return null
    if (!global.document || global.window !== global || !global.location ||
        !/^https?:$/.test(global.location.protocol || '') || typeof global.fetch !== 'function') {
      throw new Error('directBaseUrl requires a browser page; do not initialize during SSR')
    }
    var value = config.directBaseUrl, url
    if (typeof value !== 'string' || !/^https:\/\/[^/?#\\\s@]+\/?$/.test(value)) {
      throw new Error('directBaseUrl must be an absolute HTTPS origin without credentials, path, query or fragment')
    }
    try { url = new global.URL(value) } catch (error) { throw new Error('Invalid directBaseUrl HTTPS origin') }
    if (!url.hostname || url.hostname.indexOf('*') !== -1 || url.username || url.password || url.port === '0') throw new Error('Invalid directBaseUrl HTTPS origin')
    return url.origin
  }

  function uuid() {
    if (global.crypto && global.crypto.randomUUID) return global.crypto.randomUUID()
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0
      var v = c === 'x' ? r : (r & 0x3 | 0x8)
      return v.toString(16)
    })
  }

  function MpTracker(config) {
    if (!config || typeof config.appKey !== 'string' || !config.appKey) throw new Error('appKey is required')
    // Validate before loading/mutating caches, creating timers or sending automatic events.
    var directBaseUrl = directOrigin(config)
    var scope = encodeURIComponent(config.appKey + '|' + (config.endpoint || '').replace(/\/$/, ''))
    if (instances[scope]) {
      if (instances[scope].directBaseUrl !== directBaseUrl) throw new Error('Conflicting directBaseUrl for an existing tracker; reload with one configuration')
      return instances[scope]
    }
    this.storageKey = STORAGE_KEY + ':' + scope
    this.deviceKey = DEVICE_KEY + ':' + scope
    this.installKey = '__mp_installed__:' + scope
    this.appKey = config.appKey
    this.endpoint = (config.endpoint || '').replace(/\/$/, '')
    // Keep endpoint as the historical storage namespace; only transport changes.
    Object.defineProperty(this, 'directBaseUrl', {value: directBaseUrl, enumerable: true})
    var batchSize = Number(config.maxBatchSize)
    this.maxBatchSize = Number.isFinite(batchSize) && batchSize > 0 ? Math.min(50, Math.max(1, Math.floor(batchSize))) : 50
    this.flushInterval = config.flushInterval || 10000
    this.onEventRejected = typeof config.onEventRejected === 'function' ? config.onEventRejected : null
    this.queue = this._load()
    this._migrateLegacy()
    this.deviceId = this._deviceId()
    this.appVersion = config.appVersion
    if (config.appVersionCode != null && (!/^[0-9]{1,10}$/.test(String(config.appVersionCode)) || Number(config.appVersionCode) > 2147483647)) throw new Error('appVersionCode must be an integer build code')
    this.appVersionCode = config.appVersionCode == null ? undefined : Number(config.appVersionCode)
    this.setCommonFields(config.commonFields || {})
    // Compatibility accessor only; attribution belongs to the account on the server.
    Object.defineProperty(this,'firstChannel',{get:function(){return acquisitionChannel(this._ruleContext.channel)},enumerable:true})
    this._startupIds = new Set()
    this._startupDeadline = Date.now() + 60000
    var runtime = {}, self = this
    Object.defineProperty(this, '_runtimeFields', {get: function () { return runtime }, set: function (fields) {
      runtime = fields
      if (fields && fields.user_id) self._resolveStartupIdentity(fields.user_id)
    }})
    this._sending = false
    this._timer = setInterval(this.flush.bind(this), this.flushInterval)
    if (global.addEventListener) {
      global.addEventListener('pagehide', function () { this.track('app_exit'); this.flush() }.bind(this))
      global.addEventListener('pageshow', function (e) { if (e.persisted) { this.track('app_launch'); this._pageView() } }.bind(this))
      global.addEventListener('hashchange', this._pageView.bind(this))
      global.addEventListener('popstate', this._pageView.bind(this))
      global.addEventListener('__mp_page_navigation__', this._pageView.bind(this))
      if (global.history && !global.history.__mpTrackingHooked) {
        global.history.__mpTrackingHooked = true
        ;['pushState', 'replaceState'].forEach(function (method) {
          var original = global.history[method]
          if (typeof original !== 'function') return
          global.history[method] = function () {
            var result = original.apply(this, arguments)
            if (global.dispatchEvent && global.Event) global.dispatchEvent(new global.Event('__mp_page_navigation__'))
            return result
          }
        })
      }
    }
    var installKey = this.installKey
    try {
      if (!global.localStorage.getItem(installKey)) {
        if (this._isNewDevice) this.track('app_install')
        global.localStorage.setItem(installKey, '1')
      }
    } catch (e) {}
    this.track('app_launch')
    this._pageView()
    instances[scope] = this
  }

  MpTracker.prototype._pageView = function () {
    var location = global.location || {}
    var url = location.href || ''
    if (this._lastPageUrl === url) return
    this._lastPageUrl = url
    this.track('page_view', { page_name: location.pathname || '', page_url: url })
  }

  /** 设置之后每个事件都会携带的额外公共字段，与 track 的 params 分开。 */
  MpTracker.prototype.setCommonFields = function (fields) {
    var common = Object.assign({}, fields || {}), context = {}
    Object.keys(RULE_EVENT_KEYS).forEach(function (key) {
      var eventKey = RULE_EVENT_KEYS[key]
      if (Object.prototype.hasOwnProperty.call(common, eventKey)) {
        var value = contextValue(common[eventKey])
        if (value !== undefined) context[key] = value
        delete common[eventKey]
      }
    })
    this.commonFields = common
    this._ruleContext = context
  }

  // Patch only these five fields. null/blank removes an override; language then uses device language.
  MpTracker.prototype.setRuleContext = function (fields) {
    var context = Object.assign({}, this._ruleContext || {})
    Object.keys(fields || {}).forEach(function (key) {
      if (!Object.prototype.hasOwnProperty.call(RULE_EVENT_KEYS, key)) throw new Error('Unsupported rule context field: ' + key)
      var value = contextValue(fields[key])
      if (value === undefined) delete context[key]; else context[key] = value
    })
    this._ruleContext = context
  }
  MpTracker.prototype.getRuleContext = function () {
    var context = Object.assign({}, this._ruleContext || {})
    context.channel=acquisitionChannel(context.channel)
    var language = (global.navigator || {}).language
    if (!context.language && typeof language === 'string' && language.trim()) context.language = language
    return context
  }

  MpTracker.prototype._deviceId = function () {
    var d
    try {
      d = global.localStorage.getItem(this.deviceKey)
      if (!d) {
        this._isNewDevice = true
        d = uuid()
        global.localStorage.setItem(this.deviceKey, d)
        if (global.localStorage.getItem(this.deviceKey) !== d) throw new Error('Device identity was not persisted')
      }
    } catch (e) {
      throw new Error('Device identity storage unavailable; guest initialization stopped. Retry after enabling site storage.')
    }
    return d
  }

  MpTracker.prototype._migrateLegacy = function () {
    try {
      if (global.localStorage.getItem('__mp_installed__' + this.appKey)) {
        var previous = global.localStorage.getItem(DEVICE_KEY)
        if (previous && !global.localStorage.getItem(this.deviceKey)) global.localStorage.setItem(this.deviceKey, previous)
        global.localStorage.setItem(this.installKey, '1')
      }
      var legacy = JSON.parse(global.localStorage.getItem(STORAGE_KEY) || '[]')
      var owned = legacy.filter(function (e) { return e.app_key === this.appKey }, this)
      if (owned.length) {
        this.queue = this.queue.concat(owned)
        this._persist()
        global.localStorage.setItem(STORAGE_KEY, JSON.stringify(legacy.filter(function (e) { return e.app_key !== this.appKey }, this)))
        var oldDevice = global.localStorage.getItem(DEVICE_KEY)
        if (oldDevice && !global.localStorage.getItem(this.deviceKey)) global.localStorage.setItem(this.deviceKey, oldDevice)
      }
    } catch (e) { /* Never assign an unidentifiable legacy event to another APP. */ }
  }
  MpTracker.prototype._load = function () {
    try {
      var raw = global.localStorage.getItem(this.storageKey)
      var queue = raw ? JSON.parse(raw) : []
      return Array.isArray(queue) ? queue : []
    } catch (e) { return [] }
  }
  MpTracker.prototype._persist = function () {
    try { global.localStorage.setItem(this.storageKey, JSON.stringify(this.queue)) } catch (e) {}
  }

  MpTracker.prototype._notifyRejected = function (detail) {
    try { if (this.onEventRejected) this.onEventRejected(detail) } catch (_) { /* Diagnostics cannot block the queue. */ }
  }

  /** Optional transport-only credential. Never copied into an event or the offline cache. */
  MpTracker.prototype.setCollectionTokenProvider = function (provider) {
    if (provider != null && typeof provider !== 'function') throw new Error('Token provider must be a function or null')
    this._collectionTokenProvider = provider || null
  }

  /** Minimal browser facts for pre-registration guest identity matching. No user/token fields. */
  MpTracker.prototype.webIdentityContext = function () {
    var nav=global.navigator||{}, scr=global.screen||{}, context=this.getRuleContext(), result={
      os_version:nav.platform||'',screen_resolution:(scr.width||0)+'x'+(scr.height||0),
      device_language:context.language||nav.language||'',timezone_offset:-new Date().getTimezoneOffset()
    }
    var model=this.commonFields&&this.commonFields.device_model
    if(typeof model==='string'&&model.trim())result.device_model=model
    return result
  }

  /** 公共字段自动采集。 */
  MpTracker.prototype._common = function () {
    var nav = global.navigator || {}
    var scr = global.screen || {}
    var tz = 0
    try { tz = -new Date().getTimezoneOffset() } catch (e) {}
    var context = this.getRuleContext(), common = Object.assign({}, this.commonFields, this._runtimeFields || {})
    if (context.adGroup != null) common.adgroup = context.adGroup
    if (context.adCreative != null) common.creative = context.adCreative
    return {
      country_code: context.country,
      channel: context.channel,
      event_id: uuid(),
      event_time: Date.now(),
      app_key: this.appKey,
      device_id: this.deviceId,
      platform: 'web',
      report_source: 'client',
      common_fields: JSON.parse(JSON.stringify(common)),
      app_version: this.appVersion,
      app_version_code: this.appVersionCode,
      sdk_version: SDK_VERSION,
      os_version: nav.platform || '',
      device_language: context.language,
      screen_resolution: (scr.width || 0) + 'x' + (scr.height || 0),
      timezone_offset: tz,
      network_type: (nav.connection && nav.connection.effectiveType) || '',
      sdk_platform: 'web'
    }
  }

  /**
   * 上报事件。
   * @param {string} name 事件名
   * @param {object} params 业务参数
   */
  MpTracker.prototype.track = function (name, params) {
    var ev
    try {
      ev = JSON.parse(JSON.stringify(Object.assign(this._common(), {
        event_name: name,
        params: params || {}
      })))
    } catch (_) {
      this._notifyRejected({code:40001, reason:'unserializable_event'})
      return
    }
    if (this._startupIds && Date.now() < this._startupDeadline && !ev.common_fields.user_id && ['app_install','app_launch','page_view'].includes(name)) this._startupIds.add(ev.event_id)
    this.queue.push(ev)
    this._persist()
    if (this.queue.length >= this.maxBatchSize) this.flush()
  }

  /** Call once per actual display (including each banner refresh); retain the handle for paid callbacks. */
  MpTracker.prototype.beginAdImpression = function (inventoryId, adNetwork, adUnitId, impressionId) {
    var fields={ad_inventory_id:inventoryId,ad_revenue_network:adNetwork,ad_revenue_unit_id:adUnitId,ad_impression_id:impressionId||uuid()}
    Object.keys(fields).forEach(function(k){if(typeof fields[k]!=='string'||!fields[k].trim()||fields[k].length>128||/[\x00-\x1f]/.test(fields[k]))throw new Error('广告曝光标识无效')})
    var template=this._common()
    return {appKey:this.appKey, fields:JSON.parse(JSON.stringify(fields)), template:template}
  }
  /** No provider credentials are required. Amount must be a decimal string; no implicit CPM conversion. */
  MpTracker.prototype.reportAdRevenue = function (impression, value, unit, currency, precision) {
    precision=precision||'estimated'
    if(!impression||impression.appKey!==this.appKey||!impression.template||!impression.fields)throw new Error('曝光不属于当前App')
    if(typeof value!=='string'||!/^\d{1,12}(\.\d{1,12})?$/.test(value)||!['per_impression','micros','ecpm','bid_cpm'].includes(unit)||! /^[A-Z]{3}$/.test(currency)||!['exact','estimated','publisher_defined','unknown'].includes(precision)||(['ecpm','bid_cpm'].includes(unit)&&precision!=='estimated'))throw new Error('广告金额、单位、币种或精度无效')
    var scale=(value.split('.')[1]||'').replace(/0+$/,'').length, maxScale=unit==='micros'?6:['ecpm','bid_cpm'].includes(unit)?9:12
    if(scale>maxScale)throw new Error('广告金额换算后最多12位小数')
    var ev=JSON.parse(JSON.stringify(impression.template))
    ev.event_id=uuid();ev.event_name='ad_impression_revenue'
    ev.params=Object.assign({},impression.fields,{ad_impression_time_ms:ev.event_time,ad_revenue_value:value,ad_revenue_unit:unit,ad_revenue_currency:currency,ad_revenue_precision:precision})
    this.queue.push(ev);this._persist();if(this.queue.length>=this.maxBatchSize)this.flush()
    return ev.event_id
  }

  MpTracker.prototype._resolveStartupIdentity = function (userId) {
    if (!this._startupIds) return
    if (userId && Date.now() < this._startupDeadline) {
      var ids = this._startupIds
      this.queue.forEach(function (event) {
        if (event && ids.has(event.event_id) && event.common_fields && !event.common_fields.user_id) event.common_fields.user_id = userId
      })
      this._persist()
    }
    this._startupIds = null
  }

  MpTracker.prototype.flush = function () {
    var self = this
    if (this._runtimeFields.user_id) this._resolveStartupIdentity(this._runtimeFields.user_id)
    if (this._startupIds && this._startupIds.size && this.queue.some(function(e) { return e && this._startupIds.has(e.event_id) }, this)) {
      if (Date.now() < this._startupDeadline) return
      this._startupIds = null
    }
    if (this._sending || !this.queue.length) return
    var batch = this.queue.slice(0, Math.min(50, this.maxBatchSize))
    var body = JSON.stringify({ appKey: this.appKey, deviceId: this.deviceId, events: batch })
    this._sending = true

    var request = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Platform': '3' },
      body: body,
      keepalive: true
    }
    try {
      var token = this._collectionTokenProvider && this._collectionTokenProvider()
      if (typeof token === 'string' && token.trim() && !/[\r\n]/.test(token)) request.headers.Authorization = 'Bearer ' + token
    } catch (_) { /* Optional session proof must not stop anonymous collection. */ }
    if (this.directBaseUrl) { request.credentials = 'omit'; request.redirect = 'error' }
    global.fetch((this.directBaseUrl || this.endpoint) + '/api/v1/track/collect', request)
      .then(function (res) { if (res.ok === false) throw new Error('collection failed'); return res.json() })
      .then(function (json) {
        if (json && json.code === 0) {
          var data = json.data
          var rejected = []
          if (data && Object.prototype.hasOwnProperty.call(data, 'rejected')) {
            if (data.accepted !== batch.length || !Array.isArray(data.rejected)) return
            var indexes = new Set()
            for (var item of data.rejected) {
              if (!item || !Number.isInteger(item.index) || item.index < 0 || item.index >= batch.length ||
                  indexes.has(item.index) || !((item.code === 40001 && item.reason === 'invalid_event') ||
                    (item.code === 40901 && item.reason === 'event_conflict'))) return
              indexes.add(item.index)
              var event = batch[item.index]
              var detail = {index:item.index, code:item.code, reason:item.reason}
              if (event && typeof event.event_id === 'string') detail.eventId = event.event_id
              rejected.push(detail)
            }
          }
          self.queue.splice(0, batch.length)
          self._persist()
          rejected.forEach(function (detail) { self._notifyRejected(detail) })
        }
      })
      .catch(function () { /* 留在队列，下次重传 */ })
      .finally(function () { self._sending = false })
  }

  Object.defineProperty(MpTracker, 'sdkVersion', {value: SDK_VERSION})
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = MpTracker
    if (typeof window === 'undefined') return
  }
  global.MpTracker = MpTracker
})(typeof window !== 'undefined' ? window : globalThis)
