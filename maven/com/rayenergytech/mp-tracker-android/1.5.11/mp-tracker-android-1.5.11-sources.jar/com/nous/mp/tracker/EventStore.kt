package com.nous.mp.tracker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 离线事件队列：持久化到 SharedPreferences（JSON 数组）。
 * 上报成功后删除；失败保留，下次重传。
 */
class EventStore(context: Context) {

    private val prefs =
        context.getSharedPreferences("mp_tracker_queue", Context.MODE_PRIVATE)

    @Synchronized
    fun add(event: JSONObject) {
        val arr = load()
        arr.put(event)
        save(arr)
    }

    @Synchronized
    fun bindStartup(ids: Set<String>, userId: String) {
        val events = load()
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            if (event.optString("event_id") !in ids) continue
            val fields = event.optJSONObject("common_fields") ?: JSONObject()
            if (fields.optString("user_id").isBlank()) { fields.put("user_id", userId); event.put("common_fields", fields) }
        }
        save(events)
    }

    @Synchronized
    fun peek(max: Int): JSONArray {
        val all = load()
        val n = minOf(max, all.length())
        val batch = JSONArray()
        for (i in 0 until n) batch.put(all.get(i))
        return batch
    }

    @Synchronized
    fun remove(count: Int) {
        val all = load()
        val remain = JSONArray()
        for (i in count until all.length()) remain.put(all.get(i))
        save(remain)
    }

    @Synchronized
    fun size(): Int = load().length()

    private fun load(): JSONArray =
        try { JSONArray(prefs.getString(KEY, "[]") ?: "[]") }
        catch (e: Exception) { JSONArray() }

    private fun save(arr: JSONArray) {
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    companion object {
        private const val KEY = "events"
    }
}
