package com.nous.mp.tracker

import java.util.Locale

/** 兼容获取设备语言（BCP-47 尽量）。 */
internal object LocaleCompat {
    fun language(): String = Locale.getDefault().toLanguageTag()
}
