package com.nous.mp.tracker

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.provider.Settings
import org.json.JSONObject
import java.util.TimeZone
import java.util.UUID

/** 设备与公共字段采集。 */
object DeviceInfo {

    private const val PREFS = "mp_tracker_prefs"
    private const val KEY_DEVICE_ID = "device_id"

    lateinit var deviceId: String
        private set
    lateinit var recoveryId: String
        private set
    var isNewInstall: Boolean = false
        private set

    internal lateinit var appContext: Context
        private set

    private lateinit var packageInfo: android.content.pm.PackageInfo

    @SuppressLint("HardwareIds")
    fun init(context: Context) {
        appContext = context.applicationContext
        packageInfo = appContext.packageManager.getPackageInfo(appContext.packageName, 0)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val stable = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        check(stable != null && stable.matches(Regex("[0-9a-fA-F]{16}")) && stable != "9774d56d682e549c" && stable != "0000000000000000") { "稳定设备标识暂不可用，请重试；未创建新游客" }
        recoveryId = "android:" + stable.lowercase(java.util.Locale.ROOT)
        val existing = prefs.getString(KEY_DEVICE_ID, null)
        isNewInstall = existing.isNullOrBlank()
        val id = existing?.takeIf { it.isNotBlank() } ?: recoveryId
        check(prefs.edit().putString(KEY_DEVICE_ID, id).commit()) { "设备标识保存失败，未创建新游客" }
        deviceId = id
    }

    fun versionCode(): Int {
        val info = packageInfo
        val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        require(code in 0..Int.MAX_VALUE.toLong()) { "versionCode must be a non-negative int32 build code" }
        return code.toInt()
    }

    @SuppressLint("HardwareIds")
    fun buildEvent(appKey: String, eventName: String, params: JSONObject?): JSONObject {
        val res = appContext.resources
        val dm = res.displayMetrics
        val appInfo = packageInfo
        val isTablet =
            (res.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK) >=
            Configuration.SCREENLAYOUT_SIZE_LARGE
        return JSONObject().apply {
            put("event_id", UUID.randomUUID().toString())
            put("event_name", eventName)
            put("event_time", System.currentTimeMillis())
            put("app_key", appKey)
            put("device_id", deviceId)
            put("platform", "android")
            put("report_source", "client")
            appInfo?.let {
                put("app_version", it.versionName ?: "")
                put("app_version_code", versionCode())
            }
            put("sdk_version", MpSdkVersion.VERSION)
            put("os_version", Build.VERSION.RELEASE ?: "")
            put("device_brand", Build.BRAND ?: "")
            put("device_model", Build.MODEL ?: "")
            put("device_type", if (isTablet) "tablet" else "phone")
            put("screen_resolution", "${dm.widthPixels}x${dm.heightPixels}")
            put("device_language", LocaleCompat.language())
            put("timezone_offset", TimeZone.getDefault().rawOffset / 60000)
            put("network_type", NetworkInfo.type(appContext))
            put("carrier", NetworkInfo.carrier(appContext))
            put("params", params ?: JSONObject())
        }
    }
}
