package com.nous.mp.tracker

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Call session methods on the main thread. Callbacks are delivered on the main thread. */
class MpClient(private val apiBase: String, appCode: String, versionCode: Int = DeviceInfo.versionCode(),
               paymentChannel: String? = null, contextFields: JSONObject = JSONObject(), private val tracker: MpTracker = MpTracker.get(), private val paymentEnvironment: String = "production", guestRestoreMode: String? = null, private val autoGuestLogin: Boolean = true) {
    private val guestRestore = GuestRestorePolicy(guestRestoreMode)
    private val main = Handler(Looper.getMainLooper())
    // Preserve upload/withdrawal order on this client, without delaying login or payment traffic.
    private val advertisingRequests = java.util.concurrent.Executors.newSingleThreadExecutor { task ->
        Thread(task, "mp-advertising-requests").apply { isDaemon = true }
    }
    var onSessionChanged: (() -> Unit)? = null
    var onInitializationError: ((Throwable) -> Unit)? = null
    var initializationError: Throwable? = null
        private set
    private var autoGuestEligible=false
    private var autoStartupCancelled=false
    private val initializationWaiters=mutableListOf<(Result<JSONObject>)->Unit>()
    private val guestLoginWaiters=mutableListOf<(Result<JSONObject>)->Unit>()
    fun initializeSession(callback:(Result<JSONObject>)->Unit){
        check(Looper.myLooper()==Looper.getMainLooper())
        initializationWaiters.add(callback);if(initializationWaiters.size>1)return
        fun finish(result:Result<JSONObject>){val callbacks=initializationWaiters.toList();initializationWaiters.clear();callbacks.forEach{runCatching{it(result)}}}
        if(hasSession)refresh(::finish)
        else if(guestLoginWaiters.isNotEmpty() || autoGuestEligible && !autoStartupCancelled)loginGuest(::finish)
        else finish(Result.failure(IllegalStateException(if(sessionStorageError!=null)"Token cache unavailable" else "Login required")))
    }
    private val renewalWaiters = mutableListOf<(Result<JSONObject>) -> Unit>()
    private var renewing = false
    @Volatile private var token: String? = null
    private val sessionStore = MpSessionStore(DeviceInfo.appContext, org.json.JSONArray(listOf(apiBase.trimEnd('/'), appCode, "2", DeviceInfo.deviceId)).toString())
    private val handoffStore = MpSessionStore(DeviceInfo.appContext, org.json.JSONArray(listOf(apiBase.trimEnd('/'), appCode, "2", DeviceInfo.deviceId, "handoff")).toString())
    var sessionStorageError: String? = null
        private set
    val hasSession: Boolean get() = !token.isNullOrBlank()
    class AccountDeletedRecovery(val configuration: JSONObject) : IllegalStateException("Account deleted; a new guest session is ready. Retry the operation explicitly.") { val code=40108; val sessionRecovered=true }
    private class RequestFailure(val expired: Boolean, message: String, val deleted: Boolean = false) : IllegalStateException(message)
    private var recoveringDeleted=false
    private fun recoverDeletedSession(source: String?, callback: (Result<JSONObject>) -> Unit) {
        if(recoveringDeleted || source.isNullOrBlank() || token!=source){callback(Result.failure(IllegalStateException("Replacement session unavailable")));return}
        recoveringDeleted=true
        fun finish(result: Result<JSONObject>){recoveringDeleted=false;callback(result)}
        var expected=epoch+1;setSession(source)
        if(epoch!=expected || token!=source){finish(Result.failure(IllegalStateException("Session changed; discarded recovery")));return}
        post("/api/v1/client/accounts/recover-deleted",JSONObject().put("device",accountBody()).put("deletedToken",source),false){result -> result.fold({login ->
            try{guestRestore.validateLogin(login);val next=login.optString("accessToken");check(next.isNotBlank()){ "Missing access token" };expected=epoch+1;setSession(next)
                if(epoch!=expected || token!=next){finish(Result.failure(IllegalStateException("Session changed; discarded recovery")));return@fold}
                refresh { finish(it) }
            }catch(error:Exception){finish(Result.failure(error))}
        },{finish(Result.failure(it))})}
    }
    private var epoch = 0
    private var sequence = 0
    private val baseContext = JSONObject().put("appCode", appCode).put("platform", 2)
        .put("versionCode", versionCode).put("deviceId", DeviceInfo.deviceId)
        .apply { paymentChannel?.let { put("paymentChannel", it) } }
    private val context: JSONObject get() = JSONObject(baseContext.toString()).apply {
        tracker.ruleContextSnapshot().forEach { (key, value) -> put(key, value) }
    }
    init {
        require(versionCode == DeviceInfo.versionCode()) { "versionCode differs from the installed package build code" }
        require(paymentEnvironment in listOf("production", "sandbox"))
        check(Looper.myLooper() == Looper.getMainLooper()); require(versionCode >= 0 && appCode.isNotBlank())
        tracker.setRuleContext(listOf("country","language","channel","adGroup","adCreative")
            .filter { contextFields.has(it) }.associateWith { if (contextFields.isNull(it)) null else contextFields.getString(it) })
        try { token = sessionStore.read() } catch (e: Exception) { sessionStorageError = "Token cache unavailable" }
        tracker.runtimeFields = JSONObject().put("user_id", "").put("ab_snapshot", "{}").put("config_version", "").toString()
        tracker.setCollectionTokenProvider(if (tracker.collectionEndpoint == apiBase.trimEnd('/')) ({ token }) else null)
        autoGuestEligible=token==null&&sessionStorageError==null
        val startupEpoch=epoch;val startupSequence=sequence
        if(autoGuestLogin)main.post{if(epoch==startupEpoch&&sequence==startupSequence&&!autoStartupCancelled)initializeSession{result -> initializationError=result.exceptionOrNull();result.exceptionOrNull()?.let{runCatching{onInitializationError?.invoke(it)}}}}
    }
    fun setSession(accessToken: String?) {
        check(Looper.myLooper() == Looper.getMainLooper())
        epoch++; sequence++; token = accessToken?.takeIf { it.isNotBlank() }
        try { sessionStore.write(token); sessionStorageError = null } catch (e: Exception) { sessionStorageError = "Token cache unavailable"; runCatching { sessionStore.write(null) } }
        tracker.runtimeFields = JSONObject().put("user_id", "").put("ab_snapshot", "{}").put("config_version", "").toString()
        runCatching { onSessionChanged?.invoke() }
    }
    fun clearLocalSession() { tracker.cancelStartupIdentity(); setSession(null) }
    private fun post(path: String, body: JSONObject, authenticated: Boolean, callback: (Result<JSONObject>) -> Unit) =
        send(path, body, authenticated, true, callback)
    private fun send(path: String, body: JSONObject, authenticated: Boolean, includeRecoveryId: Boolean, callback: (Result<JSONObject>) -> Unit) {
        check(Looper.myLooper() == Looper.getMainLooper())
        val generation = epoch; val credential = token; val payload = guestRestore.requestBody(path, body).toString()
        if (authenticated && credential.isNullOrBlank()) { callback(Result.failure(IllegalStateException("Login required"))); return }
        val operation = Runnable {
            val result = runCatching {
                val connection = URL(apiBase.trimEnd('/') + path).openConnection() as HttpURLConnection
                try {
                    connection.requestMethod = "POST"; connection.connectTimeout = 15000; connection.readTimeout = 15000
                    connection.setRequestProperty("X-Payment-Environment", paymentEnvironment)
                    connection.doOutput = true; connection.setRequestProperty("Content-Type", "application/json")
                    if (authenticated) { connection.setRequestProperty("Authorization", "Bearer $credential"); if (includeRecoveryId) connection.setRequestProperty("X-Guest-Recovery-Id", DeviceInfo.recoveryId) }
                    connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                    val status = connection.responseCode
                    val text = (if (status in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
                    val response = try {JSONObject(text)}catch(error:Exception){if(authenticated&&status==401)throw RequestFailure(true,"Login expired");throw error}
                    if(authenticated && response.optInt("code")==40108)throw RequestFailure(false,"Account deleted",true)
                    if (authenticated && status == 401) throw RequestFailure(true, "Login expired")
                    if (authenticated && response.optInt("code") in listOf(40101, 40302)) throw RequestFailure(true, response.optString("message", "Login expired"))
                    check(status in 200..299 && response.optInt("code", -1) == 0) { response.optString("message", "Request failed") }
                    response.getJSONObject("data")
                } finally { connection.disconnect() }
            }
            main.post {
                if (generation != epoch) callback(Result.failure(IllegalStateException("Session changed; discarded response")))
                else if((result.exceptionOrNull() as? RequestFailure)?.deleted==true){recoverDeletedSession(credential){recovered -> callback(recovered.fold({Result.failure(AccountDeletedRecovery(it))},{Result.failure(it)}))}}
                else { if ((result.exceptionOrNull() as? RequestFailure)?.expired == true) {autoGuestEligible=false;clearLocalSession()}; callback(result) }
            }
        }
        if (includeRecoveryId) Thread(operation).start() else advertisingRequests.execute(operation)
    }
    private fun handoff(action: String, fields: JSONObject = JSONObject(), authenticated: Boolean = false, callback: (Result<JSONObject>) -> Unit) =
        post("/api/v1/client/handoff/$action", accountBody(fields), authenticated, callback)
    fun getAppHandoffSource(callback: (Result<JSONObject>) -> Unit) = handoff("current",authenticated=true,callback=callback)
    fun handoffConfig(callback: (Result<JSONObject>) -> Unit) = handoff("config", callback = callback)
    private fun handoffHash(value: String) = java.security.MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    private fun pendingHandoff(): JSONObject = handoffStore.read()?.let { JSONObject(it) } ?: error("No pending handoff")
    private fun boundHandoff(p: JSONObject) = JSONObject().put("claimId",p.getString("claimId")).put("verifier",p.getString("verifier"))
    private fun clearHandoffOnSuccess(result: Result<JSONObject>, callback: (Result<JSONObject>) -> Unit) {
        result.fold({value -> callback(runCatching {handoffStore.write(null);value})}, {callback(Result.failure(it))})
    }
    /** Pass Activity intent.data for cold start AND onNewIntent. No navigation or identity changes here. */
    fun resolveAppHandoff(uri: android.net.Uri, provider: String? = null, payload: JSONObject? = null, callback: (Result<JSONObject>) -> Unit) {
        handoffConfig { result -> result.fold({ config ->
            try {
                check(config.optInt("protocolVersion") == 1 && config.optBoolean("enabled")) { "Handoff unavailable" }
                val parameter = if(provider == null) "handoffId" else config.getString("parameter")
                if(provider != null) check(provider == config.getString("provider") && provider in listOf("appsflyer","adjust")) { "Provider mismatch" }
                else {
                    val base = android.net.Uri.parse(config.getString("baseUrl"))
                    val custom = config.optString("scheme").isNotEmpty() && uri.scheme == config.optString("scheme") && uri.host == "handoff"
                    check(if(custom) uri.getQueryParameter("appCode") == context.getString("appCode") else uri.scheme == "https" && uri.host == base.host && uri.port == base.port && uri.path == "/api/v1/public/handoff/" + context.getString("appCode")) { "Untrusted handoff URL" }
                }
                val id = if(provider == "appsflyer") payload?.optString(parameter) else uri.getQueryParameter(parameter)
                check(id != null && id.matches(Regex("[A-Za-z0-9_-]{20,64}"))) { "Missing handoff context" }
                handoff("resolve",JSONObject().put("handoffId",id)) { resolved -> callback(resolved.map { it.put("handoffId",id) }) }
            } catch(error: Exception) { callback(Result.failure(error)) }
        }, {callback(Result.failure(it))}) }
    }
    fun beginAppHandoff(handoffId: String, callback: (Result<JSONObject>) -> Unit) {
        try {
            val p=handoffStore.read()?.let {JSONObject(it)} ?: JSONObject().put("claimId",java.util.UUID.randomUUID().toString())
                .put("handoffId",handoffId).put("verifier",ByteArray(32).also {java.security.SecureRandom().nextBytes(it)}.joinToString("") {"%02x".format(it)})
                .put("oldTokenHash",handoffHash(token ?: ""))
            check(p.getString("handoffId") == handoffId) { "Cancel existing handoff first" }
            handoffStore.write(p.toString())
            handoff("claim",JSONObject().put("claimId",p.getString("claimId")).put("handoffId",handoffId).put("challenge",handoffHash(p.getString("verifier"))),hasSession,callback)
        } catch(error: Exception) {callback(Result.failure(error))}
    }
    fun appHandoffStatus(callback: (Result<JSONObject>) -> Unit) {try {handoff("status",boundHandoff(pendingHandoff()),callback=callback)}catch(error: Exception){callback(Result.failure(error))}}
    fun cancelAppHandoff(callback: (Result<JSONObject>) -> Unit) {try {handoff("cancel",boundHandoff(pendingHandoff())) {result -> clearHandoffOnSuccess(result,callback)}}catch(error: Exception){callback(Result.failure(error))}}
    fun completeAppHandoff(switchConfirmed: Boolean, callback: (Result<JSONObject>) -> Unit) {
        try {
            check(switchConfirmed) { "Explicit switch confirmation required" }
            val p=pendingHandoff();val current=handoffHash(token ?: "");val generation=epoch
            check(current == p.getString("oldTokenHash") || current == p.optString("newTokenHash")) { "Session changed; start a new handoff" }
            val body=boundHandoff(p).put("switchConfirmed",true)
            handoff("status",body) {state -> state.fold({ status ->
                if(status.optString("status") in listOf("acknowledged","delivered","recovery_expired") && current == p.optString("newTokenHash")) {
                    getAccount { verified -> verified.fold({ account ->
                        if(account.optString("userId") != p.optString("newUserId")) callback(Result.failure(IllegalStateException("Handoff account mismatch")))
                        else {
                            tracker.runtimeFields=JSONObject(tracker.runtimeFields).put("user_id",account.getString("userId")).toString()
                            if(status.optString("status") == "acknowledged")clearHandoffOnSuccess(verified,callback)
                            else handoff("ack",body,true) {ack -> clearHandoffOnSuccess(ack.map {account},callback)}
                        }
                    }, {callback(Result.failure(it))}) };return@fold
                }
                handoff("redeem",body) { result -> result.fold({ login ->
                    try {
                        check(generation == epoch) { "Session changed" }
                        val credential=login.getString("accessToken");check(credential.isNotBlank() && login.getString("userId").isNotBlank())
                        p.put("newTokenHash",handoffHash(credential)).put("newUserId",login.getString("userId"));handoffStore.write(p.toString())
                        // Write first. A failed encrypted write never clears or replaces the old session.
                        sessionStore.write(credential);token=credential;epoch++;sequence++;sessionStorageError=null
                        tracker.runtimeFields=JSONObject().put("user_id", "").put("ab_snapshot", "{}").put("config_version", "").toString()
                        runCatching {onSessionChanged?.invoke()}
                        getAccount { account -> account.fold({ value ->
                            if(value.optString("userId") != login.getString("userId")) callback(Result.failure(IllegalStateException("Handoff account mismatch")))
                            else {
                                tracker.runtimeFields=JSONObject(tracker.runtimeFields).put("user_id",login.getString("userId")).toString()
                                handoff("ack",body,true) { ack -> clearHandoffOnSuccess(ack.map {login},callback) }
                            }
                        }, {callback(Result.failure(it))}) }
                    } catch(error: Exception) {callback(Result.failure(error))}
                }, {callback(Result.failure(it))}) }
            }, {callback(Result.failure(it))}) }
        } catch(error: Exception) {callback(Result.failure(error))}
    }
    fun reportAppHandoff(eventType: String, handoffId: String? = null, eventId: String = java.util.UUID.randomUUID().toString(), callback: (Result<JSONObject>) -> Unit) =
        handoff("event",JSONObject().put("eventType",eventType).put("handoffId",handoffId ?: "").put("eventId",eventId),callback=callback)
    /** Optional Play path; unsupported stores return failure and must not block ordinary startup. */
    fun resolvePlayInstallHandoff(callback: (Result<JSONObject>) -> Unit) {
        val client=com.android.installreferrer.api.InstallReferrerClient.newBuilder(DeviceInfo.appContext).build()
        var done=false
        fun finish(result: Result<JSONObject>) {main.post {if(!done){done=true;runCatching {client.endConnection()};callback(result)}}}
        main.postDelayed({finish(Result.failure(IllegalStateException("Install referrer timeout")))},5000)
        try {client.startConnection(object: com.android.installreferrer.api.InstallReferrerStateListener {
            override fun onInstallReferrerSetupFinished(code: Int) {
                if(code != com.android.installreferrer.api.InstallReferrerClient.InstallReferrerResponse.OK) {finish(Result.failure(IllegalStateException("Install referrer unavailable")));return}
                try {
                    val uri=android.net.Uri.parse("https://referrer.invalid/?"+client.installReferrer.installReferrer)
                    val id=uri.getQueryParameter("handoffId") ?: error("No handoff referrer")
                    check(uri.getQueryParameter("appCode") == context.getString("appCode")) { "APP mismatch" }
                    handoff("resolve",JSONObject().put("handoffId",id)) {result -> finish(result.map {it.put("handoffId",id)})}
                } catch(error: Exception){finish(Result.failure(error))}
            }
            override fun onInstallReferrerServiceDisconnected() {finish(Result.failure(IllegalStateException("Install referrer disconnected")))}
        })}catch(error: Exception){finish(Result.failure(error))}
    }
    fun loginGuest(callback: (Result<JSONObject>) -> Unit) {
        guestLoginWaiters.add(callback);if(guestLoginWaiters.size>1)return
        loginGuestImpl { result -> val callbacks=guestLoginWaiters.toList();guestLoginWaiters.clear();callbacks.forEach{runCatching{it(result)}} }
    }
    private fun loginGuestImpl(callback: (Result<JSONObject>) -> Unit) {
        if (guestRestore.clearBeforeGuestLogin) setSession(null)
        val body = accountBody()
        post("/api/v1/client/users/login/guest", body, false) { result -> result.fold({ login ->
            try { guestRestore.validateLogin(login) } catch (error: IllegalStateException) { callback(Result.failure(error)); return@fold }
            val credential = login.optString("accessToken").takeIf { it.isNotBlank() }
            if (credential == null) callback(Result.failure(IllegalStateException("Missing access token")))
            else { autoGuestEligible=false;setSession(credential); refresh(callback) }
        }, { callback(Result.failure(it)) }) }
    }
    private fun accountBody(fields: JSONObject = JSONObject()): JSONObject = JSONObject().put("appCode",context.getString("appCode")).put("deviceId",DeviceInfo.deviceId).put("platform","android").put("recoveryId",DeviceInfo.recoveryId).apply { if(context.has("country")) put("country",context.getString("country"));fields.keys().forEach { key -> put(key, fields.get(key)) };put("appCode",context.getString("appCode"));put("deviceId",DeviceInfo.deviceId);put("platform","android");put("recoveryId",DeviceInfo.recoveryId);put("channel",context.optString("channel","organic")) }.let { guestRestore.requestBody("/api/v1/client/accounts/", it) }
    private fun changeAccount(path: String, fields: JSONObject = JSONObject(), authenticated: Boolean = true, callback: (Result<JSONObject>) -> Unit) {
        if(!authenticated){autoStartupCancelled=true;if(guestLoginWaiters.isNotEmpty())setSession(token)}
        post("/api/v1/client/accounts/$path",accountBody(fields),authenticated) { result -> result.fold({ login ->
            try { guestRestore.validateLogin(login) } catch (error: IllegalStateException) { callback(Result.failure(error)); return@fold }
            val credential=login.optString("accessToken").takeIf { it.isNotBlank() }
            if(credential==null) callback(Result.failure(IllegalStateException("Missing access token"))) else { setSession(credential);refresh(callback) }
        },{ error -> if(path=="session/refresh" && error is AccountDeletedRecovery)callback(Result.success(error.configuration)) else callback(Result.failure(error)) }) }
    }
    /** Explicit opt-in only; server requires consent to advertising AND account association. */
    fun submitAdvertisingId(advertisingId: MpAdvertisingId.Result, advertisingConsent: Boolean,
                            accountLinkConsent: Boolean, callback: (Result<JSONObject>) -> Unit) {
        check(Looper.myLooper() == Looper.getMainLooper())
        if (advertisingId.status != MpAdvertisingId.Status.AVAILABLE || advertisingId.id.isNullOrBlank() || !advertisingConsent || !accountLinkConsent) {
            callback(Result.failure(IllegalArgumentException("Available advertising ID and both consents required"))); return
        }
        send("/api/v1/client/advertising/identity", JSONObject().put("advertisingId", advertisingId.id)
            .put("advertisingConsent", true).put("accountLinkConsent", true), true, false, callback)
    }
    fun advertisingIdentityStatus(callback: (Result<JSONObject>) -> Unit) =
        send("/api/v1/client/advertising/status", JSONObject(), true, false, callback)
    /** Delete advertising IDs for all installations of the current account. */
    fun revokeAdvertisingIdentity(callback: (Result<JSONObject>) -> Unit) =
        send("/api/v1/client/advertising/revoke", JSONObject(), true, false, callback)
    fun getAccount(callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/current",JSONObject(),true,callback)
    fun requestVerification(provider: String,identifier: String,purpose: String,callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/verification",accountBody(JSONObject().put("provider",provider).put("identifier",identifier).put("purpose",purpose)),purpose !in listOf("login","reset"),callback)
    fun loginMethods(callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/login-methods",accountBody(),false,callback)
    fun oauthChallenge(provider: String,callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/oauth/challenge",accountBody(JSONObject().put("provider",provider)),false,callback)
    fun loginIdentity(proof: JSONObject,callback: (Result<JSONObject>) -> Unit) = changeAccount("login",proof,false,callback)
    fun loginPassword(email: String,password: String,callback: (Result<JSONObject>) -> Unit) = changeAccount("password/login",JSONObject().put("identifier",email).put("password",password),false,callback)
    fun loginOrBindIdentity(proof: JSONObject, callback: (Result<JSONObject>) -> Unit) {
        post("/api/v1/client/accounts/login-or-bind",accountBody(proof),true) { result -> result.fold({ login ->
            try { guestRestore.validateLogin(login) } catch (error: IllegalStateException) { callback(Result.failure(error)); return@fold }
            val credential=login.optString("accessToken");val user=login.optString("userId");val action=login.optString("action")
            if(credential.isBlank() || user.isBlank() || !guestRestore.acceptsResolution(action, login.opt("accountSwitched"))) {
                callback(Result.failure(IllegalStateException("Invalid identity resolution")));return@fold
            }
            val generation=epoch+1;setSession(credential)
            if(generation!=epoch || token!=credential){callback(Result.failure(IllegalStateException("Session changed; discarded response")));return@fold}
            tracker.runtimeFields=JSONObject().put("user_id",user).put("ab_snapshot","{}").put("config_version","").toString()
            refresh { configured ->
                if(generation!=epoch || token==null) callback(Result.failure(IllegalStateException("Session changed; discarded response")))
                else {login.put("configuration",configured.getOrNull() ?: JSONObject.NULL).put("configurationRefreshRequired",configured.isFailure);callback(Result.success(login))}
            }
        },{callback(Result.failure(it))}) }
    }
    fun bindIdentity(proof: JSONObject,callback: (Result<JSONObject>) -> Unit) = changeAccount("bind",proof,true,callback)
    fun replaceIdentity(previous: JSONObject,replacement: JSONObject,callback: (Result<JSONObject>) -> Unit) = changeAccount("replace",JSONObject().put("previous",accountBody(previous)).put("replacement",accountBody(replacement)),true,callback)
    fun unbindIdentity(proof: JSONObject,callback: (Result<JSONObject>) -> Unit) = changeAccount("unbind",proof,true,callback)
    fun renewSession(callback: (Result<JSONObject>) -> Unit) {
        check(Looper.myLooper() == Looper.getMainLooper())
        renewalWaiters.add(callback); if (renewing) return
        renewing = true
        changeAccount("session/refresh") { result ->
            val callbacks = renewalWaiters.toList(); renewalWaiters.clear(); renewing = false
            val generation = epoch
            callbacks.forEach { completion -> completion(if(generation == epoch) result else Result.failure(IllegalStateException("Session changed"))) }
        }
    }
    fun renewSessionForBusiness(connectionId: String, callback: (Result<JSONObject>) -> Unit) {
        renewSession { result -> result.fold({ businessTicket(connectionId,callback) }, { callback(Result.failure(it)) }) }
    }
    /** exchangeTicket must use the host's HTTPS business endpoint; no middle-platform token is forwarded. */
    fun loginBusiness(connectionId: String, exchangeTicket: (String, (Result<JSONObject>) -> Unit) -> Unit, callback: (Result<JSONObject>) -> Unit) {
        val generation = epoch
        businessTicket(connectionId) { ticket -> ticket.fold({ payload ->
            if(generation != epoch) { callback(Result.failure(IllegalStateException("Session changed; discarded business ticket"))); return@fold }
            val value = payload.optString("ticket").takeIf { it.isNotBlank() }
            if(value == null) { callback(Result.failure(IllegalStateException("Missing ticket"))); return@fold }
            try { exchangeTicket(value) { result -> main.post {
                callback(if(generation == epoch) result else Result.failure(IllegalStateException("Session changed; discarded business response")))
            } } } catch(e: Exception) { callback(Result.failure(e)) }
        }, { callback(Result.failure(it)) }) }
    }
    fun logout(allDevices: Boolean = false,callback: (Result<JSONObject>) -> Unit) = changeAccount("logout"+(if(allDevices) "?allDevices=true" else ""),callback=callback)
    fun getSessions(callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/sessions",JSONObject(),true,callback)
    fun revokeSession(id: String,callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/sessions/revoke",JSONObject().put("sessionId",id),true,callback)
    fun businessTicket(connectionId: String,callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/business-ticket",JSONObject().put("connectionId",connectionId),true,callback)
    fun resetPassword(proof: JSONObject,callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/password/reset",accountBody(proof),false,callback)
    fun deletionPrecheck(callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/deletion/precheck",JSONObject(),true,callback)
    fun deleteAccount(proof: JSONObject,callback: (Result<JSONObject>) -> Unit) {
        post("/api/v1/client/accounts/deletion",accountBody(proof),true) { result -> if(result.isSuccess) clearLocalSession();callback(result) }
    }
    fun deletionStatus(receipt: JSONObject,callback: (Result<JSONObject>) -> Unit) = post("/api/v1/client/accounts/deletion/status",receipt,false,callback)
    fun getUserInfo(callback: (Result<JSONObject>) -> Unit) {
        if(autoGuestLogin&&!hasSession&&!autoStartupCancelled&&(guestLoginWaiters.isNotEmpty()||autoGuestEligible)){loginGuest{result -> callback(result.map{it.getJSONObject("user")})};return}
        post("/api/v1/client/runtime/user", context, true) {result -> val recovery=result.exceptionOrNull() as? AccountDeletedRecovery;callback(if(recovery!=null)Result.success(recovery.configuration.getJSONObject("user")) else result)}
    }
    fun refresh(callback: (Result<JSONObject>) -> Unit) {
        if(autoGuestLogin&&!hasSession&&!autoStartupCancelled&&(guestLoginWaiters.isNotEmpty()||autoGuestEligible)){loginGuest(callback);return}
        val request = ++sequence
        post("/api/v1/client/runtime/config", context, true) { result ->
            val recovered=result.exceptionOrNull() as? AccountDeletedRecovery
            if(recovered!=null){callback(Result.success(recovered.configuration));return@post}
            if (request != sequence) { callback(Result.failure(IllegalStateException("Superseded response"))); return@post }
            result.onSuccess { tracker.runtimeFields = JSONObject().put("user_id", it.getJSONObject("user").getString("userId")).put("ab_snapshot", it.optJSONObject("experiments")?.toString() ?: "{}").put("config_version", it.getString("configVersion")).toString() }
            callback(result)
        }
    }
}
