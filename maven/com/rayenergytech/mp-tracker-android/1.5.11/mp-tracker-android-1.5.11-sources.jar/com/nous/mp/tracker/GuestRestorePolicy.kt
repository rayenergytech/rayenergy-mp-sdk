package com.nous.mp.tracker

import org.json.JSONObject

/** Negotiation only; the server remains responsible for session permissions and restore ownership. */
internal class GuestRestorePolicy(private val mode: String?) {
    init {
        require(mode == null || mode == "same_user_restricted") { "Unsupported guestRestoreMode" }
    }

    val clearBeforeGuestLogin: Boolean get() = mode == null

    fun requestBody(path: String, body: JSONObject): JSONObject {
        if (path == "/api/v1/client/accounts/recover-deleted") return body // Negotiation belongs to the nested device.
        if (!path.startsWith("/api/v1/client/accounts/") && path != "/api/v1/client/users/login/guest") return body
        return JSONObject(body.toString()).apply {
            remove("guestRestoreMode")
            mode?.let { put("guestRestoreMode", it) }
        }
    }

    fun validateLogin(login: JSONObject) {
        check(mode == null || login.opt("guestRestoreMode") == mode) {
            "Server does not support requested guestRestoreMode"
        }
    }

    fun acceptsResolution(action: String, switched: Any?): Boolean {
        if (switched !is Boolean) return false
        return when (action) {
            "guest_upgraded" -> !switched
            "existing_account_login" -> switched
            "account_reauthenticated" -> mode != null && !switched
            else -> false
        }
    }
}
