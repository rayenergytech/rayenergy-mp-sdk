package com.nous.mp.tracker

import android.content.Context
import android.os.Build
import android.security.KeyPairGeneratorSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.math.BigInteger
import java.security.*
import java.util.Calendar
import javax.crypto.*
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.security.auth.x500.X500Principal

/** AES-GCM token storage; keys stay in AndroidKeyStore (RSA-wrapped AES on API 21/22). */
internal class MpSessionStore(private val context: Context, private val scope: String) {
    private val prefs = context.getSharedPreferences("mp_client_sessions", Context.MODE_PRIVATE)
    private val alias = "mp_client_" + MessageDigest.getInstance("SHA-256").digest(scope.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    private fun keys() = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    @Synchronized private fun key(): SecretKey {
        val store = keys()
        if (Build.VERSION.SDK_INT >= 23) {
            if (!store.containsAlias(alias)) KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
                init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
            }.generateKey()
            return store.getKey(alias, null) as SecretKey
        }
        val rsaAlias = alias + "_rsa"
        if (!store.containsAlias(rsaAlias)) {
            val end = Calendar.getInstance().apply { add(Calendar.YEAR, 30) }.time
            @Suppress("DEPRECATION")
            val spec = KeyPairGeneratorSpec.Builder(context).setAlias(rsaAlias).setSubject(X500Principal("CN=MpClient")).setSerialNumber(BigInteger.ONE).setStartDate(java.util.Date(0)).setEndDate(end).build()
            KeyPairGenerator.getInstance("RSA", "AndroidKeyStore").apply { initialize(spec) }.generateKeyPair()
        }
        val wrapped = prefs.getString(alias + "_wrapped", null)
        val rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding")
        if (wrapped != null) { rsa.init(Cipher.DECRYPT_MODE, store.getKey(rsaAlias, null)); return SecretKeySpec(rsa.doFinal(Base64.decode(wrapped, Base64.NO_WRAP)), "AES") }
        val bytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
        rsa.init(Cipher.ENCRYPT_MODE, store.getCertificate(rsaAlias).publicKey)
        check(prefs.edit().putString(alias + "_wrapped", Base64.encodeToString(rsa.doFinal(bytes), Base64.NO_WRAP)).commit()) { "Token cache unavailable" }
        return SecretKeySpec(bytes, "AES")
    }
    fun read(): String? {
        val stored = prefs.getString(alias, null) ?: return null
        try {
            val bytes = Base64.decode(stored, Base64.NO_WRAP); require(bytes.size > 12)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12))); cipher.updateAAD(scope.toByteArray(Charsets.UTF_8))
            return String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8).takeIf { it.isNotBlank() }
        } catch (e: Exception) { prefs.edit().remove(alias).remove(alias + "_wrapped").commit(); throw IllegalStateException("Token cache unavailable") }
    }
    fun write(token: String?) {
        if (token == null) { check(prefs.edit().remove(alias).commit()) { "Token cache unavailable" }; return }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key()); cipher.updateAAD(scope.toByteArray(Charsets.UTF_8))
        val encrypted = cipher.iv + cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        check(prefs.edit().putString(alias, Base64.encodeToString(encrypted, Base64.NO_WRAP)).commit()) { "Token cache unavailable" }
    }
}
