package com.nous.mp.tracker

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** 批量上报器。返回是否成功（code==0）。 */
class Reporter(private val endpoint: String, private val tokenProvider: (() -> String?)? = null) {

    fun report(appKey: String, deviceId: String, events: JSONArray): Boolean {
        var conn: HttpURLConnection? = null
        try {
            val payload = JSONObject().apply {
                put("appKey", appKey)
                put("deviceId", deviceId)
                put("events", events)
            }
            val url = URL(endpoint.trimEnd('/') + "/api/v1/track/collect")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 10_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("X-Platform", "2")
                runCatching { tokenProvider?.invoke() }.getOrNull()
                    ?.takeIf { it.isNotBlank() && !it.contains('\r') && !it.contains('\n') }
                    ?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray()) }
            val code = conn.responseCode
            if (code != 200) return false
            val body = conn.inputStream.bufferedReader().readText()
            val json = JSONObject(body)
            return json.optInt("code", -1) == 0
        } catch (e: Exception) {
            return false
        } finally {
            conn?.disconnect()
        }
    }
}
