package com.nous.mp.tracker

internal object AcquisitionChannel {
    fun normalize(raw: Any?): String {
        if(raw==null || raw==org.json.JSONObject.NULL)return "organic"
        require(raw is String){"channel must be a string"}
        val value=raw.trim()
        if(value.isEmpty() || value.lowercase(java.util.Locale.ROOT) in setOf("organic","web","ogannic","unknown","undefined","null","未知","未上报","自然量"))return "organic"
        require(value.length<=64){"channel must be at most 64 characters"}
        return value
    }
}
