package com.nous.mp.tracker

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Optional GAID access. Never changes login identity, persists IDs, or sends events. */
object MpAdvertisingId {
    enum class Status { AVAILABLE, DISABLED, LIMITED, UNAVAILABLE }

    class Result internal constructor(val id: String?, val status: Status) {
        // Avoid accidentally exposing the identifier through logging.
        override fun toString(): String = "AdvertisingIdResult(status=$status)"
    }

    class Request internal constructor() {
        private val cancelled = AtomicBoolean(false)
        fun cancel() { cancelled.set(true) }
        internal fun isCancelled(): Boolean = cancelled.get()
    }

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor { task ->
        Thread(task, "mp-advertising-id").apply { isDaemon = true }
    }

    /**
     * Call on the main thread. Both collectionAllowed and callback run on that thread.
     * Permission is checked before reading and again before delivering the result.
     * Keep collectionAllowed current; cancel the request when its owner is destroyed.
     * cancel suppresses delivery but cannot interrupt a Google Play services IPC call.
     */
    fun read(
        context: Context,
        collectionAllowed: () -> Boolean,
        callback: (Result) -> Unit
    ): Request {
        check(Looper.myLooper() == Looper.getMainLooper()) { "Call read on the main thread" }
        val request = Request()
        if (!collectionAllowed()) {
            callback(Result(null, Status.DISABLED))
            return request
        }
        val app = context.applicationContext
        executor.execute {
            if (request.isCancelled()) return@execute
            val result = readOnWorker(app)
            main.post {
                if (!request.isCancelled()) {
                    callback(if (collectionAllowed()) result else Result(null, Status.DISABLED))
                }
            }
        }
        return request
    }

    private fun readOnWorker(context: Context): Result {
        return try {
            // Optional host dependency: keep the core SDK usable without Google Play services.
            val client = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient")
            val info = client.getMethod("getAdvertisingIdInfo", Context::class.java)
                .invoke(null, context) ?: return Result(null, Status.UNAVAILABLE)
            val infoClass = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient\$Info")
            val limited = infoClass.getMethod("isLimitAdTrackingEnabled").invoke(info) as Boolean
            if (limited) return Result(null, Status.LIMITED)
            val id = (infoClass.getMethod("getId").invoke(info) as? String)?.trim()
            val valid = id != null && id.matches(Regex("[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")) &&
                id != "00000000-0000-0000-0000-000000000000"
            if (valid) Result(id, Status.AVAILABLE) else Result(null, Status.UNAVAILABLE)
        } catch (_: Exception) {
            Result(null, Status.UNAVAILABLE)
        } catch (_: LinkageError) {
            Result(null, Status.UNAVAILABLE)
        }
    }
}
