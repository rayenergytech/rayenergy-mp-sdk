package com.nous.mp.tracker

import android.content.Context
import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import org.json.JSONObject

/**
 * MP 埋点 SDK 入口（Android）。
 * 协议：POST {endpoint}/api/v1/track/collect
 */
class MpTracker private constructor(
    private val appKey: String,
    private val endpoint: String,
    private val eventStore: EventStore,
    private val reporter: Reporter,
    private val flushIntervalMs: Long,
    private val maxBatchSize: Int
) {
    private val sending = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var commonFields: String = "{}"
    private val contextGuard = Any()
    private val ruleContext = RuleContext()
    private var startupIds: MutableSet<String>? = mutableSetOf()
    private val startupDeadline = android.os.SystemClock.elapsedRealtime() + 60000
    @Volatile internal var runtimeFields: String = "{}"
        set(value) = synchronized(this) {
            field = value
            val user = JSONObject(value).optString("user_id")
            if (user.isNotBlank()) {
                startupIds?.let { if (android.os.SystemClock.elapsedRealtime() < startupDeadline) eventStore.bindStartup(it, user) }
                startupIds = null
            }
        }
    @Volatile private var collectionTokenProvider: (() -> String?)? = null
    val collectionEndpoint: String get() = endpoint.trimEnd('/')

    /** Optional send-time credential; never persisted alongside offline events. */
    @Synchronized internal fun cancelStartupIdentity() { startupIds = null }
    fun setCollectionTokenProvider(provider: (() -> String?)?) { collectionTokenProvider = provider }
    private val handler = Handler(Looper.getMainLooper())
    private val flushTask = object : Runnable {
        override fun run() {
            flush()
            handler.postDelayed(this, flushIntervalMs)
        }
    }

    init {
        handler.postDelayed(flushTask, flushIntervalMs)
    }

    /** 上报事件；params 可空。 */
    @Synchronized
    fun track(eventName: String, params: JSONObject? = null) {
        val event = captureEvent(eventName, params)
        if (android.os.SystemClock.elapsedRealtime() < startupDeadline && event.optJSONObject("common_fields")?.optString("user_id").isNullOrBlank() && eventName in setOf("app_install", "app_launch", "page_view")) startupIds?.add(event.getString("event_id"))
        eventStore.add(event)
        if (eventStore.size() >= maxBatchSize) flush()
    }

    private fun captureEvent(eventName: String, params: JSONObject?): JSONObject {
        val event = DeviceInfo.buildEvent(appKey, eventName, params)
        val (fields, context) = synchronized(contextGuard) {
            JSONObject(commonFields) to (ruleContext.snapshot(LocaleCompat.language()))
        }
        for ((key, eventKey) in RuleContext.eventKeys) {
            if (key == "adGroup" || key == "adCreative") context[key]?.let { fields.put(eventKey, it) }
            else { event.remove(eventKey); context[key]?.let { event.put(eventKey, it) } }
        }
        val runtime = JSONObject(runtimeFields)
        runtime.keys().forEach { fields.put(it, runtime.get(it)) }
        event.put("common_fields", fields)
        return event
    }

    class AdImpression internal constructor(internal val app: String, internal val template: String, internal val fields: String)
    @Synchronized
    fun beginAdImpression(inventoryId: String, adNetwork: String, adUnitId: String, impressionId: String = java.util.UUID.randomUUID().toString()): AdImpression {
        require(listOf(inventoryId, adNetwork, adUnitId, impressionId).all { it.isNotBlank() && it.length <= 128 && it.none { c -> c.code < 32 } }) { "广告曝光标识无效" }
        val fields = JSONObject().put("ad_inventory_id", inventoryId).put("ad_revenue_network", adNetwork).put("ad_revenue_unit_id", adUnitId).put("ad_impression_id", impressionId)
        return AdImpression(appKey, captureEvent("ad_impression_revenue", null).toString(), fields.toString())
    }
    @Synchronized
    fun reportAdRevenue(impression: AdImpression, value: String, unit: String, currency: String, precision: String = "estimated") {
        require(impression.app == appKey && value.matches(Regex("[0-9]{1,12}(\\.[0-9]{1,12})?")) && unit in setOf("per_impression", "micros", "ecpm", "bid_cpm") && currency.matches(Regex("[A-Z]{3}")) && precision in setOf("exact", "estimated", "publisher_defined", "unknown") && (unit !in setOf("ecpm", "bid_cpm") || precision == "estimated")) { "广告收入参数无效" }
        require(java.math.BigDecimal(value).stripTrailingZeros().scale() <= when (unit) { "micros" -> 6; "ecpm", "bid_cpm" -> 9; else -> 12 }) { "广告金额换算后最多12位小数" }
        val event = JSONObject(impression.template)
        val params = JSONObject(impression.fields).put("ad_impression_time_ms", event.getLong("event_time")).put("ad_revenue_value", value).put("ad_revenue_unit", unit).put("ad_revenue_currency", currency).put("ad_revenue_precision", precision)
        event.put("event_id", java.util.UUID.randomUUID().toString()).put("params", params)
        eventStore.add(event)
        if (eventStore.size() >= maxBatchSize) flush()
    }

    /** 设置额外公共字段，之后每个事件自动携带。 */
    fun setCommonFields(fields: JSONObject) = synchronized(contextGuard) {
        val input = fields.keys().asSequence().associateWith { fields.opt(it).takeUnless { value -> value == JSONObject.NULL } }
        commonFields = JSONObject(ruleContext.replaceCommon(input)).toString()
    }

    /** Incremental rule fields; null/blank removes an override. Call refresh after changing targeting. */
    fun setRuleContext(fields: Map<String, String?>) = synchronized(contextGuard) { ruleContext.patch(fields) }
    internal fun ruleContextSnapshot(): Map<String, String> = synchronized(contextGuard) {
        ruleContext.snapshot(LocaleCompat.language())
    }

    /** 立即尝试上报（异步线程）。 */
    @Synchronized
    fun flush() {
        if (!startupIds.isNullOrEmpty()) {
            if (android.os.SystemClock.elapsedRealtime() < startupDeadline) return
            startupIds = null
        }
        if (eventStore.size() == 0 || !sending.compareAndSet(false, true)) return
        Thread {
            try {
                val batch = eventStore.peek(maxBatchSize)
                val ok = reporter.report(appKey, DeviceInfo.deviceId, batch)
                if (ok) eventStore.remove(batch.length())
            } finally { sending.set(false) }
        }.start()
    }

    companion object {
        @Volatile
        private var instance: MpTracker? = null
        private var lifecycle: Application.ActivityLifecycleCallbacks? = null
        private var lifecycleApplication: Application? = null

        @Synchronized
        fun init(context: Context, config: Config) {
            instance?.let {
                require(it.appKey == config.appKey && it.endpoint == config.endpoint) { "SDK已初始化，切换APP或网关需重新启动进程" }
                return
            }
            require(config.maxBatchSize in 1..100 && config.flushIntervalMs > 0)
            val ctx = context.applicationContext
            DeviceInfo.init(ctx)
            AcquisitionChannel.normalize(config.commonFields.opt("channel"))
            val store = EventStore(ctx)
            val reporter = Reporter(config.endpoint) { instance?.collectionTokenProvider?.invoke() }
            instance = MpTracker(
                config.appKey, config.endpoint, store, reporter,
                config.flushIntervalMs, config.maxBatchSize
            )
            val tracker = instance!!
            tracker.setCommonFields(config.commonFields)
            val prefs = ctx.getSharedPreferences("mp_tracker_lifecycle", Context.MODE_PRIVATE)
            val installKey = "installed_" + config.appKey
            if (!prefs.getBoolean(installKey, false)) {
                if (DeviceInfo.isNewInstall) tracker.track("app_install")
                prefs.edit().putBoolean(installKey, true).apply()
            }
            tracker.track("app_launch")
            lifecycle?.let { lifecycleApplication?.unregisterActivityLifecycleCallbacks(it) }
            val app = ctx as? Application
            var started = 0
            var firstForeground = true
            var changingConfiguration = false
            lifecycle = object : Application.ActivityLifecycleCallbacks {
                override fun onActivityStarted(activity: Activity) {
                    if (started == 0 && !firstForeground && !changingConfiguration) tracker.track("app_launch")
                    firstForeground = false
                    changingConfiguration = false
                    started++
                }
                override fun onActivityStopped(activity: Activity) {
                    started = (started - 1).coerceAtLeast(0)
                    changingConfiguration = activity.isChangingConfigurations
                    if (started == 0 && !changingConfiguration) { tracker.track("app_exit"); tracker.flush() }
                }
                override fun onActivityResumed(activity: Activity) { tracker.track("page_view", JSONObject().put("page_name", activity.javaClass.simpleName)) }
                override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
                override fun onActivityPaused(activity: Activity) {}
                override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
                override fun onActivityDestroyed(activity: Activity) {}
            }
            lifecycleApplication = app
            app?.registerActivityLifecycleCallbacks(lifecycle!!)
        }

        fun get(): MpTracker =
            instance ?: throw IllegalStateException("MpTracker 未初始化，请先调用 init()")
    }

    /** 配置。 */
    data class Config(
        val appKey: String,
        val endpoint: String,
        val flushIntervalMs: Long = 10_000,
        val maxBatchSize: Int = 100,
        val commonFields: JSONObject = JSONObject()
    )
}
