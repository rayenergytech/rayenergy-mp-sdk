package com.nous.mp.tracker

import android.content.Context
import android.net.ConnectivityManager
import android.telephony.TelephonyManager

/** 网络类型与运营商。 */
object NetworkInfo {

    @Suppress("DEPRECATION")
    fun type(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return ""
        val active = cm.activeNetworkInfo ?: return ""
        return when (active.type) {
            ConnectivityManager.TYPE_WIFI -> "wifi"
            ConnectivityManager.TYPE_MOBILE -> ConnectManagerCompat.mobileType(active.subtype)
            else -> ""
        }
    }

    @Suppress("DEPRECATION")
    fun carrier(context: Context): String {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        return tm?.networkOperatorName ?: ""
    }
}

internal object ConnectManagerCompat {
    @Suppress("DEPRECATION")
    fun mobileType(subtype: Int): String = when (subtype) {
        TelephonyManager.NETWORK_TYPE_LTE -> "4g"
        TelephonyManager.NETWORK_TYPE_NR -> "5g"
        else -> "mobile"
    }
}
