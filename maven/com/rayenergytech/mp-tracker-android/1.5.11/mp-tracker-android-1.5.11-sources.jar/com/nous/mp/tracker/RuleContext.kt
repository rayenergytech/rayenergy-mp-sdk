package com.nous.mp.tracker

/** One source for event fields and rule request fields. Country is supplied by the host. */
internal class RuleContext {
    companion object {
        val eventKeys = linkedMapOf("country" to "country_code", "language" to "device_language",
            "channel" to "channel", "adGroup" to "adgroup", "adCreative" to "creative")
        private fun value(raw: Any?): String? {
            require(raw == null || raw is String) { "Rule context values must be strings or null" }
            return (raw as String?)?.takeIf { it.isNotBlank() }
        }
    }
    private var values = emptyMap<String, String>()
    fun patch(fields: Map<String, Any?>) {
        val next = values.toMutableMap()
        for ((key, raw) in fields) {
            require(eventKeys.containsKey(key)) { "Unsupported rule context field: $key" }
            val text = value(raw)
            if (text == null) next.remove(key) else next[key] = text
        }
        values = next.toMap()
    }
    fun replaceCommon(fields: Map<String, Any?>): Map<String, Any?> {
        val next = linkedMapOf<String, String>()
        for ((key, eventKey) in eventKeys) if (fields.containsKey(eventKey)) value(fields[eventKey])?.let { next[key] = it }
        values = next.toMap()
        return fields.filterKeys { it !in eventKeys.values }
    }
    fun snapshot(deviceLanguage: String?): Map<String, String> = values.toMutableMap().apply {
        put("channel", AcquisitionChannel.normalize(get("channel")))
        if (!containsKey("language") && !deviceLanguage.isNullOrBlank()) put("language", deviceLanguage)
    }.toMap()
}
