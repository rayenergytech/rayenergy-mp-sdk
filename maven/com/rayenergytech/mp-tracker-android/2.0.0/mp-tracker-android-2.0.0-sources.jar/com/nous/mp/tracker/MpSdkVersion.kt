// Generated from sdks/VERSION by SdkRelease.java; do not edit.
package com.nous.mp.tracker

object MpSdkVersion {
    const val VERSION = "2.0.0"
}
